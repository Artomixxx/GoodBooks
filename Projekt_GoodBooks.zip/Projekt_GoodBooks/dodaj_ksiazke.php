<?php
// Pobranie danych z żądania POST w formacie JSON
$requestPayload = file_get_contents('php://input');
$data = json_decode($requestPayload, true);

// Sprawdzenie, czy dane zostały prawidłowo przesłane
if (!$data || !isset($data['title']) || !isset($data['authors']) || !isset($data['average_rating']) || !isset($data['publication_year'])) {
    http_response_code(400); // Bad Request
    echo json_encode(['message' => 'Nieprawidłowe dane']);
    exit();
}

// Pobranie danych z przesłanego żądania
$title = $data['title'];
$authors = $data['authors'];
$averageRating = $data['average_rating'];
$publicationYear = $data['publication_year'];

// Połączenie z bazą danych
$servername = "localhost";
$username = "user";
$password = "pass";
$dbname = "goodbooks";

$conn = new mysqli($servername, $username, $password, $dbname);

// Sprawdzenie połączenia
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Przygotowanie zapytania SQL
$sql = "INSERT INTO books (title, authors, average_rating, original_publication_year)
        VALUES ('$title', '$authors', $averageRating, $publicationYear)";

// Wykonanie zapytania
if ($conn->query($sql) === true) {
    // Książka została dodana pomyślnie
    $response = ['message' => 'Książka dodana pomyślnie'];
    http_response_code(201); // Created
} else {
    // Wystąpił błąd podczas dodawania książki
    $response = ['message' => 'Wystąpił błąd podczas dodawania książki'];
    http_response_code(500); // Internal Server Error
}

// Zamykanie połączenia z bazą danych
$conn->close();

// Ustawienie nagłówków odpowiedzi
header('Content-Type: application/json');

// Zwrócenie odpowiedzi w formacie JSON
echo json_encode($response);
?>
