<?php
session_start();

// Sprawdzenie czy użytkownik jest zalogowany jako administrator
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'administrator') {
    header('Location: login.php');
    exit();
}

// Przekierowanie na stronę logowania po wylogowaniu
if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: index.php');
    exit();
}

require 'vendor/autoload.php'; // Dodaj tę linię na początku pliku

use Illuminate\Database\Capsule\Manager as Capsule; // Dodaj tę linię na początku pliku

// Połączenie z bazą danych za pomocą Eloquent
$capsule = new Capsule;
$capsule->addConnection([
    'driver' => 'mysql',
    'host' => 'localhost',
    'database' => 'goodbooks',
    'username' => 'user',
    'password' => 'pass',
    'charset' => 'utf8',
    'collation' => 'utf8_unicode_ci',
    'prefix' => '',
]);
$capsule->setAsGlobal();
$capsule->bootEloquent();

// Dodatkowy import dla Eloquent
use Illuminate\Database\Eloquent\Model;

// Klasa dla tabeli "books" w bazie danych
class Book extends Model {
    protected $table = 'books';
    protected $primaryKey = 'id';
    public $timestamps = false;
}

// Sprawdzenie czy formularz został przesłany
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Pobranie danych z formularza
    $title = $_POST['title'];
    $authors = $_POST['authors'];
    $averageRating = $_POST['average_rating'];
    $publicationYear = $_POST['publication_year'];

    // Sprawdzenie czy istnieje książka o podanym tytule
    $existingBook = Book::where('title', $title)->first();

    // Jeśli istnieje książka o podanym tytule, dokonaj edycji
    if ($existingBook) {
        $existingBook->authors = $authors;
        $existingBook->average_rating = $averageRating;
        $existingBook->original_publication_year = $publicationYear;
        $existingBook->save();
    } else {
        // W przeciwnym razie, dodaj nową książkę
        $newBook = new Book();
        $newBook->title = $title;
        $newBook->authors = $authors;
        $newBook->average_rating = $averageRating;
        $newBook->original_publication_year = $publicationYear;
        $newBook->save();
    }

    // Przekierowanie na stronę główną po dodaniu/edycji książki
    header('Location: admin_panel.php');
    exit();
}
?>
