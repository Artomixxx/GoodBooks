<?php
session_start();

// Sprawdzenie czy użytkownik jest zalogowany jako administrator
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'administrator') {
    header('Location: login.php');
    exit();
}

// Przekierowanie na stronę logowania po wylogowaniu
if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: index.php');
    exit();
}

require 'vendor/autoload.php'; // Dodaj tę linię na początku pliku

use Illuminate\Database\Capsule\Manager as Capsule; // Dodaj tę linię na początku pliku

// Połączenie z bazą danych za pomocą Eloquent
$capsule = new Capsule;
$capsule->addConnection([
    'driver' => 'mysql',
    'host' => 'localhost',
    'database' => 'goodbooks',
    'username' => 'user',
    'password' => 'pass',
    'charset' => 'utf8',
    'collation' => 'utf8_unicode_ci',
    'prefix' => '',
]);
$capsule->setAsGlobal();
$capsule->bootEloquent();

// Dodatkowy import dla Eloquent
use Illuminate\Database\Eloquent\Model;

// Klasa dla tabeli "books" w bazie danych
class Book extends Model {
    protected $table = 'books';
    protected $primaryKey = 'id';
    public $timestamps = false;
}

// Sprawdzenie czy formularz został przesłany
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Pobranie tytułu usuwanej książki
    $title = $_POST['title'];

    // Znalezienie i usunięcie książki o podanym tytule
    $bookToDelete = Book::where('title', $title)->first();
    if ($bookToDelete) {
        $bookToDelete->delete();
    }

    // Przekierowanie na stronę główną po usunięciu książki
    header('Location: admin_panel.php');
    exit();
}
?>
