<?php
header('Content-Type: text/html; charset=utf-8');
// Dane logowania do bazy danych
$host = 'localhost';
$username = "user";
$password = "pass";
$dbname = "goodbooks";

// Domyślne wartości zakresu w lat
$startYear = 2000;
$endYear = 2010;

// Wyszukiwanie po autorze lub tytule (dodane zmienne i warunek)
$searchType = '';
$searchValue = '';

// Sprawdzanie, czy formularz został wysłany
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Pobieranie wartości z formularza
    $startYear = $_POST['startYear'];
    $endYear = $_POST['endYear'];
    $searchType = isset($_POST['searchType']) ? $_POST['searchType'] : '';
    $searchValue = isset($_POST['searchValue']) ? $_POST['searchValue'] : '';

    // Sprawdzanie poprawności zakresu lat
    if ($startYear > $endYear) {
        $error = "Rok początkowy nie może być większy niż rok końcowy!";
    }
}


try {
    // Połączenie z bazą danych
    $db = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $query = "SELECT books.title, books.average_rating, books.authors, books.original_title, books.original_publication_year
              FROM books
              WHERE (books.original_publication_year BETWEEN :startYear AND :endYear+0.00001)";

    $db->exec("SET TRANSACTION ISOLATION LEVEL READ COMMITTED"); // ustawienie poziomu izolacji
    // start transakcji
    $db->beginTransaction();


    // Wyszukiwanie po autorze lub tytule
    if (!empty($searchValue)) {
        if ($searchType === 'author') {
            $query .= " AND books.authors LIKE :searchValue";
        } elseif ($searchType === 'title') {
            $query .= " AND books.title LIKE :searchValue";
        }
    }

    $query .= " ORDER BY books.average_rating DESC
                LIMIT 10";

    // Przygotowanie zapytania
    $stmt = $db->prepare($query);

    // Przypisanie wartości parametrów
    $stmt->bindParam(':startYear', $startYear);
    $stmt->bindParam(':endYear', $endYear);
    if (!empty($searchValue)) {
        if ($searchType === 'author' || $searchType === 'title') {
            $searchValue = '%' . $searchValue . '%';
            $stmt->bindParam(':searchValue', $searchValue);
        }
    }
    // Wykonanie zapytania
    $stmt->execute();

    // Pobranie wyników z bazy danych
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Sprawdzenie, czy zapytanie zwróciło jakiekolwiek wyniki
    if (empty($results)) {
        $noBooksMessage = "Brak książek dla wybranego roku lub zakresu lat.";
    }
} catch (PDOException $e) {
    // Przywrócenie stanu początkowego w przypadku błędu
    $db->rollBack();
    echo "Błąd połączenia z bazą danych: " . $e->getMessage();
}

// Funkcja eksportująca wyniki do pliku XML
function exportToXML($results) {
    $xml = new SimpleXMLElement('<books></books>');

    foreach ($results as $row) {
        $book = $xml->addChild('book');
        $book->addChild('title', $row['title']);
        $book->addChild('authors', $row['authors']);
        $book->addChild('average_rating', $row['average_rating']);
    }

    $xml->asXML('exported/exported_books.xml');
}

// Funkcja eksportująca wyniki do pliku JSON
function exportToJSON($results) {
    $json = json_encode($results, JSON_PRETTY_PRINT);
    file_put_contents('exported/exported_books.json', $json);
}

// Funkcja eksportująca wyniki do pliku SQL
function exportToSQL($results) {
    $sql = "INSERT INTO exported_books (title, authors, average_rating) VALUES ";

    foreach ($results as $row) {
        $title = addslashes($row['title']);
        $author = addslashes($row['authors']);
        $averageRating = $row['average_rating'];
        $sql .= "('$title', '$author', $averageRating), ";
    }

    $sql = rtrim($sql, ', ');
    file_put_contents('exported/exported_books.sql', $sql);
}

// Sprawdzanie, czy przycisk eksportu został kliknięty
if (isset($_POST['export'])) {
    $exportType = $_POST['export'];

    switch ($exportType) {
        case 'xml':
            exportToXML($results);
            break;
        case 'json':
            exportToJSON($results);
            break;
        case 'sql':
            exportToSQL($results);
            break;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>GoodBooks</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <style>
    .details-row {
        background-color: #f5f5f5;
    }

    .details-content {
        padding: 10px;
    }
</style>

</head>
<body>
    <div class="header">
        <a class="login-button" href="login.php">Admin</a>
    </div>

    <div class="container">
        <h1>GoodBooks</h1>

        <form method="POST" action="">
            <label for="startYear">Rok początkowy:</label>
            <input type="range" name="startYear" id="startYearSlider" min="1900" max="2022" value="<?php echo $startYear; ?>" oninput="updateStartYear(this.value); updateStartYearInput(this.value)">
            <input type="number" name="startYearInput" id="startYearInput" min="1900" max="2022" value="<?php echo $startYear; ?>" oninput="updateStartYearSlider(this.value)">
            <br><br>


            <label for="endYear">Rok końcowy:</label>
            <input type="range" name="endYear" id="endYearSlider" min="1900" max="2022" value="<?php echo $endYear; ?>" oninput="updateEndYear(this.value); updateEndYearInput(this.value)">
            <input type="number" name="endYearInput" id="endYearInput" min="1900" max="2022" value="<?php echo $endYear; ?>" oninput="updateEndYearSlider(this.value)">
            <br><br>

            <label for="searchType">Wyszukaj po:</label>
            <select name="searchType" id="searchType">
                <option value="author" <?php if ($searchType === 'author') echo 'selected'; ?>>Autorze</option>
                <option value="title" <?php if ($searchType === 'title') echo 'selected'; ?>>Tytule</option>
            </select>
            <input type="text" name="searchValue" value="<?php echo $searchValue; ?>" placeholder="Wprowadź wartość">
            <br><br>

            <input type="submit" value="Zatwierdź">
        </form>

        <?php if (isset($error)): ?>
            <p class="error-message"><?php echo $error; ?></p>
        <?php elseif (isset($noBooksMessage)): ?>
            <p class="info-message"><?php echo $noBooksMessage; ?></p>
            <?php elseif (!empty($results)): ?>
    <h2>Najlepsze książki <?php echo ($startYear === $endYear) ? "z roku $startYear" : "z lat $startYear-$endYear"; ?>:</h2>
    <table>
            <tr>
                <th>Tytuł</th>
                <th>Autor</th>
                <th>Rok wydania</th>
                <th>Ocena</th>
                <th>Szczegóły</th>
            </tr>
            <?php foreach ($results as $row): ?>
                <tr>
                    <td><?php echo $row['title']; ?></td>
                    <td><?php echo $row['authors']; ?></td>
                    <td><?php echo $row['original_publication_year']; ?></td>
                    <td><?php echo $row['average_rating']; ?></td>
                    <td>
                        <button onclick="toggleBookDetails('<?php echo $row['original_title']; ?>')">Pokaż/ukryj szczegóły</button>
                    </td>
                </tr>
                <tr>
                    <td colspan="5" class="details-row">
                        <div class="details-content" id="<?php echo $row['original_title']; ?>-content" style="display: none;"></div>
                    </td>
                </tr>
            <?php endforeach; ?>
        </table>


            <div>
            <h3>Eksportuj najlepsze książki:</h3>
                <form method="POST" action="">
                    <input type="hidden" name="startYear" value="<?php echo $startYear; ?>">
                    <input type="hidden" name="endYear" value="<?php echo $endYear; ?>">
                    <button type="submit" name="export" value="xml" class="export-button">XML</button>
                    <button type="submit" name="export" value="json" class="export-button">JSON</button>
                    <button type="submit" name="export" value="sql" class="export-button">SQL</button>
                </form>
            </div>
        <?php endif; ?>
    </div>

    <script>
        

        function updateStartYear(value) {
            document.getElementById('startYearInput').value = value;
        }

        function updateStartYearInput(value) {
            document.getElementById('startYearSlider').value = value;
        }

        function updateEndYear(value) {
            document.getElementById('endYearInput').value = value;
        }

        function updateEndYearInput(value) {
            document.getElementById('endYearSlider').value = value;
        }

        function updateStartYearSlider(value) {
            document.getElementById('startYearSlider').value = value;
            document.getElementById('startYearInput').value = value;
        }

        function updateEndYearSlider(value) {
            document.getElementById('endYearSlider').value = value;
            document.getElementById('endYearInput').value = value;
        }

        function toggleBookDetails(bookTitle) {
        var detailsContent = document.getElementById(bookTitle + '-content');
        if (detailsContent.style.display === "none") {
            detailsContent.style.display = "block";
            loadBookDetails(bookTitle, detailsContent);
        } else {
            detailsContent.style.display = "none";
        }
    }

    function loadBookDetails(bookTitle, detailsContent) {
        var xhr = new XMLHttpRequest();
        var url = 'https://www.googleapis.com/books/v1/volumes?q=' + encodeURIComponent(bookTitle) + '&key=AIzaSyAxo-dZ3i3IzTdNg7IKHKZyFHJRuAV7BjU';

        xhr.onreadystatechange = function() {
            if (xhr.readyState === 4 && xhr.status === 200) {
                var response = JSON.parse(xhr.responseText);
                if (response.items && response.items.length > 0) {
                    var volumeInfo = response.items[0].volumeInfo;
                    var thumbnail = volumeInfo.imageLinks && volumeInfo.imageLinks.thumbnail ? volumeInfo.imageLinks.thumbnail : '';
                    var description = volumeInfo.description ? volumeInfo.description : 'Brak informacji o książce.';
                    var content = '<div class="book-details">' +
                                    '<img src="' + thumbnail + '">' +
                                    '<div class="description">' + description + '</div>' +
                                  '</div>';
                    detailsContent.innerHTML = content;
                }
            }
        };

        xhr.open('GET', url, true);
        xhr.send();
    }
    </script>
</body>
</html>
