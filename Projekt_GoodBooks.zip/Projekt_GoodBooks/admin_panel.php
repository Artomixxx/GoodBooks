<?php
session_start();

// Sprawdzenie czy użytkownik jest zalogowany jako administrator
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'administrator') {
    header('Location: login.php');
    exit();
}

// Przekierowanie na stronę logowania po wylogowaniu
if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: index.php');
    exit();
}

require 'vendor/autoload.php'; // Dodaj tę linię na początku pliku

use Illuminate\Database\Capsule\Manager as Capsule; // Dodaj tę linię na początku pliku

// Połączenie z bazą danych za pomocą Eloquent
$capsule = new Capsule;
$capsule->addConnection([
    'driver' => 'mysql',
    'host' => 'localhost',
    'database' => 'goodbooks',
    'username' => 'user',
    'password' => 'pass',
    'charset' => 'utf8',
    'collation' => 'utf8_unicode_ci',
    'prefix' => '',
]);
$capsule->setAsGlobal();
$capsule->bootEloquent();

// Dodatkowy import dla Eloquent
use Illuminate\Database\Eloquent\Model;

// Klasa dla tabeli "books" w bazie danych
class Book extends Model {
    protected $table = 'books';
    protected $primaryKey = 'id';
    public $timestamps = false;
}

// Pobranie wszystkich książek z bazy danych
function getAllBooks() {
    return Book::all();
}

// Pobranie wszystkich książek
$books = getAllBooks();
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Panel Administratora</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
    <div class="header">
        <form method="GET" action="admin_panel.php">
            <input class="logout-button" type="submit" name="logout" value="Wyloguj">
        </form>
    </div>

    <div class="container">
        <h1>Panel Administratora</h1>

        <h2>Dodaj, edytuj lub usuń książkę:</h2>
        <form method="POST" action="dodaj_edytuj_ksiazke.php">
            <label for="title">Tytuł:</label>
            <input type="text" name="title" required>
            <br><br>

            <label for="authors">Autorzy:</label>
            <input type="text" name="authors" required>
            <br><br>

            <label for="average_rating">Ocena średnia:</label>
            <input type="number" name="average_rating" step="0.1" min="0" max="10" required>
            <br><br>
            
            <label for="publication_year">Rok publikacji:</label>
            <input type="number" name="publication_year" required>
            <br><br>

            <input type="submit" value="Dodaj/Edytuj książkę">
        </form>

        <h2>Usuń książkę:</h2>
        <form method="POST" action="usun_ksiazke.php">
            <label for="title">Tytuł książki do usunięcia:</label>
            <input type="text" name="title" required>
            <br><br>
            
            <input type="submit" value="Usuń książkę">
        </form>
        
        <h2>Lista książek:</h2>
        <table>
            <tr>
                <th>Tytuł</th>
                <th>Autorzy</th>
                <th>Ocena średnia</th>
                <th>Rok publikacji</th>
            </tr>
            <?php foreach ($books as $book) { ?>
                <tr>
                    <td><?php echo $book->title; ?></td>
                    <td><?php echo $book->authors; ?></td>
                    <td><?php echo $book->average_rating; ?></td>
                    <td><?php echo $book->original_publication_year; ?></td>
                </tr>
            <?php } ?>
        </table>
    </div>
</body>
</html>
