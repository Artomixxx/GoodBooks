<?php
session_start();

// Sprawdzenie czy użytkownik jest zalogowany jako moderator
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'moderator') {
    header('Location: login.php');
    exit();
}

// Przekierowanie na stronę logowania po wylogowaniu
if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: index.php');
    exit();
}

require 'vendor/autoload.php'; // Dodaj tę linię na początku pliku

use Illuminate\Database\Capsule\Manager as Capsule; // Dodaj tę linię na początku pliku

// Połączenie z bazą danych za pomocą Eloquent
$capsule = new Capsule;
$capsule->addConnection([
    'driver' => 'mysql',
    'host' => 'localhost',
    'database' => 'goodbooks',
    'username' => 'user',
    'password' => 'pass',
    'charset' => 'utf8',
    'collation' => 'utf8_unicode_ci',
    'prefix' => '',
]);
$capsule->setAsGlobal();
$capsule->bootEloquent();

// Dodatkowy import dla Eloquent
use Illuminate\Database\Eloquent\Model;

// Klasa dla tabeli "books" w bazie danych
class Book extends Model {
    protected $table = 'books';
    protected $primaryKey = 'id';
    public $timestamps = false;
}

// Pobieranie wszystkich książek
function getAllBooks() {
    return Book::all();
}

// Obsługa żądania POST do dodania nowej książki
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $url = 'http://localhost/Projekt_GoodBooks/dodaj_ksiazke.php';

    // Dane do przesłania
    $data = [
        'title' => $_POST['title'],
        'authors' => $_POST['authors'],
        'average_rating' => $_POST['average_rating'],
        'publication_year' => $_POST['publication_year']
    ];

    // Utworzenie żądania POST
    $options = [
        'http' => [
            'method' => 'POST',
            'header' => 'Content-Type: application/json',
            'content' => json_encode($data)
        ]
    ];

    // Wykonanie żądania POST
    $context = stream_context_create($options);
    $result = file_get_contents($url, false, $context);

    // Przetworzenie odpowiedzi
    $response = json_decode($result, true);

    if ($response && isset($response['message'])) {
        echo $response['message'];
    }
}

// Pobranie wszystkich książek z bazy danych
$books = getAllBooks();
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Panel Moderatora</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
    <div class="header">
        <form method="GET" action="moderator_panel.php">
            <input class="logout-button" type="submit" name="logout" value="Wyloguj">
        </form>
    </div>

    <div class="container">
        <h1>Panel Moderatora</h1>

        <h2>Dodaj nową książkę:</h2>
        <form method="POST" action="moderator_panel.php">
            <label for="title">Tytuł:</label>
            <input type="text" name="title" required>
            <br><br>

            <label for="authors">Autorzy:</label>
            <input type="text" name="authors" required>
            <br><br>

            <label for="average_rating">Ocena średnia:</label>
            <input type="number" name="average_rating" step="0.1" min="0" max="10" required>
            <br><br>

            <label for="publication_year">Rok publikacji:</label>
            <input type="number" name="publication_year" required>
            <br><br>

            <input type="submit" value="Dodaj książkę">
        </form>

        <h2>Lista książek:</h2>
        <table>
            <tr>
                <th>Tytuł</th>
                <th>Autorzy</th>
                <th>Ocena średnia</th>
                <th>Rok publikacji</th>
            </tr>
            <?php foreach ($books as $book) { ?>
                <tr>
                    <td><?php echo $book->title; ?></td>
                    <td><?php echo $book->authors; ?></td>
                    <td><?php echo $book->average_rating; ?></td>
                    <td><?php echo $book->original_publication_year; ?></td>
                </tr>
            <?php } ?>
        </table>
    </div>
</body>
</html>
