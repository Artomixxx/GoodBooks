<?php
require 'vendor/autoload.php'; // Dodaj tę linię na początku pliku

use Illuminate\Database\Capsule\Manager as Capsule; // Dodaj tę linię na początku pliku

session_start();
header('Content-Type: text/html; charset=utf-8');

// Połączenie z bazą danych za pomocą Eloquent
$capsule = new Capsule;
$capsule->addConnection([
    'driver' => 'mysql',
    'host' => 'localhost',
    'database' => 'logowanie',
    'username' => 'user',
    'password' => 'pass',
    'charset' => 'utf8',
    'collation' => 'utf8_unicode_ci',
    'prefix' => '',
]);
$capsule->setAsGlobal();
$capsule->bootEloquent();

// Dodatkowe importy dla Eloquent
use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;

// Klasa dla tabeli "tokens" w bazie danych
class Token extends Model {
    protected $table = 'tokens';
    protected $primaryKey = 'id';
    public $timestamps = false;
}

// Klasa dla tabeli "users" w bazie danych
class User extends Model {
    protected $table = 'users';
    protected $primaryKey = 'id';
    public $timestamps = false;
}

// Funkcja do generowania unikalnego tokenu
function generateToken() {
    return bin2hex(random_bytes(16));
}

if (isset($_SESSION['user_role'])) {
    // Użytkownik już zalogowany, przekierowanie na odpowiednią stronę
    if ($_SESSION['user_role'] === 'administrator') {
        header('Location: admin_panel.php');
        exit();
    } elseif ($_SESSION['user_role'] === 'moderator') {
        header('Location: moderator_panel.php');
        exit();
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Pobranie wartości z formularza
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Weryfikacja danych logowania za pomocą Eloquent
    $user = User::where('username', $username)->where('password', $password)->first();

    if ($user) {
        // Zalogowanie użytkownika
        $_SESSION['user_id'] = $user->id;
        $_SESSION['user_role'] = $user->role;

        // Generowanie tokenu
        $token = generateToken();

        // Zapisanie tokenu w bazie danych za pomocą Eloquent
        $tokenModel = new Token;
        $tokenModel->user_id = $user->id;
        $tokenModel->token = $token;
        $tokenModel->save();

        // Przekazanie tokenu do klienta (np. zapis w sesji, ciasteczko)
        $_SESSION['token'] = $token;

        // Przekierowanie na odpowiednią stronę
        if ($user->role === 'administrator') {
            header('Location: admin_panel.php');
            exit();
        } elseif ($user->role === 'moderator') {
            header('Location: moderator_panel.php');
            exit();
        }
    } else {
        $error = "Niepoprawna nazwa użytkownika lub hasło.";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>GoodBooks - Logowanie</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
    <div class="header">
        <a class="login-button" href="index.php">Powrót</a>
    </div>

    <div class="container">
        <h1>GoodBooks - Logowanie</h1>

        <?php if (isset($error)) { ?>
            <p><?php echo $error; ?></p>
        <?php } ?>

        <form method="POST" action="login.php" onsubmit="return validateForm()">
            <label for="username">Nazwa użytkownika:</label>
            <input type="text" id="username" name="username" required>
            <br><br>

            <label for="password">Hasło:</label>
            <input type="password" id="password" name="password" required>
            <br><br>

            <input type="submit" value="Zaloguj">
        </form>
    </div>

    <script>
        function validateForm() {
            var username = document.getElementById('username').value;
            var password = document.getElementById('password').value;

            if (username.trim() === '') {
                alert('Proszę wprowadzić nazwę użytkownika.');
                return false;
            }

            if (password.trim() === '') {
                alert('Proszę wprowadzić hasło.');
                return false;
            }

            return true;
        }
    </script>
</body>
</html>
